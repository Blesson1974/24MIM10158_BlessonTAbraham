package com.hotel.staff.mapper;

import com.hotel.staff.dto.ApplicationRequest;
import com.hotel.staff.dto.ApplicationResponse;
import com.hotel.staff.model.Application;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface ApplicationMapper {

    ApplicationResponse toResponse(Application application);

    @Mapping(target = "id", ignore = true)
    Application toEntity(ApplicationRequest request);

    @Mapping(target = "id", ignore = true)
    void updateEntityFromRequest(ApplicationRequest request, @MappingTarget Application entity);
}
