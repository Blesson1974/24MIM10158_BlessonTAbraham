package com.hotel.staff.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "applications")
public class Application {
    @Id
    private String id;
    
    private String name;
    private String email;
    private String phone;
    private String position;
    private String resumeText;
    private String status; // e.g., PENDING, REVIEWED, ACCEPTED, REJECTED
}
