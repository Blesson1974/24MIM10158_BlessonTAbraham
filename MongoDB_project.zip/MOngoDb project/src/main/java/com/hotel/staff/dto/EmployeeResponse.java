package com.hotel.staff.dto;

import com.hotel.staff.model.Role;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeResponse {
    private String id;
    private String name;
    private String email;
    private String phone;
    private Double salary;
    private Role role;
}
