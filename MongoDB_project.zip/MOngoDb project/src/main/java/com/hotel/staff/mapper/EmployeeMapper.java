package com.hotel.staff.mapper;

import com.hotel.staff.dto.EmployeeRequest;
import com.hotel.staff.dto.EmployeeResponse;
import com.hotel.staff.dto.RegisterRequest;
import com.hotel.staff.model.Employee;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface EmployeeMapper {

    EmployeeResponse toResponse(Employee employee);

    @Mapping(target = "id", ignore = true)
    Employee toEntity(EmployeeRequest request);

    @Mapping(target = "id", ignore = true)
    Employee toEntity(RegisterRequest request);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "password", ignore = true) // Handle password separately if not updated in standard request
    void updateEntityFromRequest(EmployeeRequest request, @MappingTarget Employee entity);
}
