package com.hotel.staff.service;

import com.hotel.staff.dto.EmployeeRequest;
import com.hotel.staff.dto.EmployeeResponse;
import com.hotel.staff.exception.ResourceNotFoundException;
import com.hotel.staff.mapper.EmployeeMapper;
import com.hotel.staff.model.Employee;
import com.hotel.staff.repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class EmployeeService {

    private final EmployeeRepository employeeRepository;
    private final EmployeeMapper employeeMapper;
    private final PasswordEncoder passwordEncoder;

    public Page<EmployeeResponse> getAllEmployees(Pageable pageable) {
        log.info("Fetching all employees with pagination: {}", pageable);
        return employeeRepository.findAll(pageable)
                .map(employeeMapper::toResponse);
    }

    public EmployeeResponse getEmployeeById(String id) {
        log.info("Fetching employee with id: {}", id);
        return employeeMapper.toResponse(getEmployeeEntityById(id));
    }

    public Employee getEmployeeEntityById(String id) {
        return employeeRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Employee not found with id: {}", id);
                    return new ResourceNotFoundException("Employee not found with id: " + id);
                });
    }

    public EmployeeResponse createEmployee(EmployeeRequest request) {
        log.info("Creating new employee with email: {}", request.getEmail());
        if (employeeRepository.existsByEmail(request.getEmail())) {
            throw new IllegalArgumentException("Error: Email is already in use!");
        }

        Employee employee = employeeMapper.toEntity(request);
        employee.setPassword(passwordEncoder.encode(request.getPassword()));
        
        Employee savedEmployee = employeeRepository.save(employee);
        log.info("Employee created successfully with id: {}", savedEmployee.getId());
        return employeeMapper.toResponse(savedEmployee);
    }

    public EmployeeResponse updateEmployee(String id, EmployeeRequest request) {
        log.info("Updating employee with id: {}", id);
        Employee existingEmployee = getEmployeeEntityById(id);
        
        employeeMapper.updateEntityFromRequest(request, existingEmployee);
        
        if (request.getPassword() != null && !request.getPassword().isEmpty()) {
            existingEmployee.setPassword(passwordEncoder.encode(request.getPassword()));
        }
        
        Employee updatedEmployee = employeeRepository.save(existingEmployee);
        log.info("Employee updated successfully with id: {}", id);
        return employeeMapper.toResponse(updatedEmployee);
    }

    public void deleteEmployee(String id) {
        log.info("Deleting employee with id: {}", id);
        if (!employeeRepository.existsById(id)) {
            log.error("Employee not found with id: {}", id);
            throw new ResourceNotFoundException("Employee not found with id: " + id);
        }
        employeeRepository.deleteById(id);
        log.info("Employee deleted successfully with id: {}", id);
    }
}
