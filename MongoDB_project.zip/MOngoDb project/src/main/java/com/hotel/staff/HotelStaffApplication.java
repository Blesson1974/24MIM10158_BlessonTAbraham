package com.hotel.staff;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelStaffApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelStaffApplication.class, args);
	}
}
