package com.hotel.staff.model;

public enum Role {
    MANAGER,
    STAFF,
    APPLICANT
}
