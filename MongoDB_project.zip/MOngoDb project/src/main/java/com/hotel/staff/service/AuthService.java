package com.hotel.staff.service;

import com.hotel.staff.dto.AuthRequest;
import com.hotel.staff.dto.AuthResponse;
import com.hotel.staff.dto.EmployeeResponse;
import com.hotel.staff.dto.RegisterRequest;
import com.hotel.staff.mapper.EmployeeMapper;
import com.hotel.staff.model.Employee;
import com.hotel.staff.model.Role;
import com.hotel.staff.repository.EmployeeRepository;
import com.hotel.staff.security.JwtUtil;
import com.hotel.staff.security.UserDetailsImpl;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthService {

    private final AuthenticationManager authenticationManager;
    private final EmployeeRepository employeeRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    private final EmployeeMapper employeeMapper;

    public AuthResponse authenticateUser(AuthRequest loginRequest) {
        log.info("Authenticating user: {}", loginRequest.getEmail());
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginRequest.getEmail(), loginRequest.getPassword()));

        SecurityContextHolder.getContext().setAuthentication(authentication);
        String jwt = jwtUtil.generateJwtToken(authentication);

        UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();
        List<String> roles = userDetails.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.toList());

        log.info("User {} authenticated successfully", loginRequest.getEmail());
        return new AuthResponse(jwt,
                userDetails.getId(),
                userDetails.getUsername(),
                roles.isEmpty() ? null : roles.get(0));
    }

    public EmployeeResponse registerUser(RegisterRequest signUpRequest) {
        log.info("Registering new user with email: {}", signUpRequest.getEmail());
        if (employeeRepository.existsByEmail(signUpRequest.getEmail())) {
            log.error("Email already in use: {}", signUpRequest.getEmail());
            throw new IllegalArgumentException("Error: Email is already in use!");
        }

        Employee employee = employeeMapper.toEntity(signUpRequest);
        employee.setPassword(passwordEncoder.encode(signUpRequest.getPassword()));
        
        if (employee.getRole() == null) {
            employee.setRole(Role.STAFF);
        }

        Employee savedEmployee = employeeRepository.save(employee);
        log.info("User registered successfully with id: {}", savedEmployee.getId());
        return employeeMapper.toResponse(savedEmployee);
    }
}
