package com.hotel.staff.service;

import com.hotel.staff.dto.ApplicationRequest;
import com.hotel.staff.dto.ApplicationResponse;
import com.hotel.staff.exception.ResourceNotFoundException;
import com.hotel.staff.mapper.ApplicationMapper;
import com.hotel.staff.model.Application;
import com.hotel.staff.repository.ApplicationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class ApplicationService {

    private final ApplicationRepository applicationRepository;
    private final ApplicationMapper applicationMapper;

    public ApplicationResponse submitApplication(ApplicationRequest request) {
        log.info("Submitting new application for position: {}", request.getPosition());
        Application application = applicationMapper.toEntity(request);
        if (application.getStatus() == null || application.getStatus().isEmpty()) {
            application.setStatus("PENDING");
        }
        Application savedApplication = applicationRepository.save(application);
        log.info("Application submitted successfully with id: {}", savedApplication.getId());
        return applicationMapper.toResponse(savedApplication);
    }

    public Page<ApplicationResponse> getAllApplications(Pageable pageable) {
        log.info("Fetching all applications with pagination: {}", pageable);
        return applicationRepository.findAll(pageable)
                .map(applicationMapper::toResponse);
    }

    public ApplicationResponse getApplicationById(String id) {
        log.info("Fetching application with id: {}", id);
        return applicationMapper.toResponse(getApplicationEntityById(id));
    }

    public Application getApplicationEntityById(String id) {
        return applicationRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Application not found with id: {}", id);
                    return new ResourceNotFoundException("Application not found with id: " + id);
                });
    }

    public ApplicationResponse updateApplicationStatus(String id, String status) {
        log.info("Updating application status for id: {} to: {}", id, status);
        Application application = getApplicationEntityById(id);
        application.setStatus(status);
        Application updatedApplication = applicationRepository.save(application);
        log.info("Application status updated successfully for id: {}", id);
        return applicationMapper.toResponse(updatedApplication);
    }
}
