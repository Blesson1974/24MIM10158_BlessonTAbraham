package com.hotel.staff.repository;

import com.hotel.staff.model.Application;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

@Repository
public interface ApplicationRepository extends MongoRepository<Application, String> {
    Page<Application> findByStatus(String status, Pageable pageable);
    Page<Application> findByPosition(String position, Pageable pageable);
    Page<Application> findByNameContainingIgnoreCase(String name, Pageable pageable);
}
