package com.hotel.staff.config;

import com.hotel.staff.model.Application;
import com.hotel.staff.model.Employee;
import com.hotel.staff.model.Role;
import com.hotel.staff.repository.ApplicationRepository;
import com.hotel.staff.repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class DataSeeder implements CommandLineRunner {

    private final EmployeeRepository employeeRepository;
    private final ApplicationRepository applicationRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        seedEmployees();
        seedApplications();
    }

    private void seedEmployees() {
        if (employeeRepository.findByEmail("admin.rahul@hotel.com").isEmpty()) {
            log.info("Seeding initial employees...");

            Employee manager = Employee.builder()
                    .name("Rahul Sharma")
                    .email("admin.rahul@hotel.com")
                    .password(passwordEncoder.encode("password123"))
                    .phone("9876543210")
                    .salary(85000.0)
                    .role(Role.MANAGER)
                    .build();

            Employee staff1 = Employee.builder()
                    .name("Priya Patel")
                    .email("priya.p@hotel.com")
                    .password(passwordEncoder.encode("password123"))
                    .phone("9123456789")
                    .salary(38000.0)
                    .role(Role.STAFF)
                    .build();

            Employee staff2 = Employee.builder()
                    .name("Amit Kumar")
                    .email("amitk88@hotel.com")
                    .password(passwordEncoder.encode("password123"))
                    .phone("9988776655")
                    .salary(41500.0)
                    .role(Role.STAFF)
                    .build();

            employeeRepository.saveAll(List.of(manager, staff1, staff2));
            log.info("Employees seeded successfully.");
        } else {
            log.info("Employees already exist. Skipping seeding.");
        }
    }

    private void seedApplications() {
        if (applicationRepository.count() == 0) {
            log.info("Seeding initial applications...");

            Application app1 = Application.builder()
                    .name("Vikram Singh")
                    .email("vikram.s99@gmail.com")
                    .phone("9876543211")
                    .position("Receptionist")
                    .resumeText("I have 3 years of experience working at the front desk of a local hotel in Delhi. Good communication skills in English and Hindi.")
                    .status("PENDING")
                    .build();

            Application app2 = Application.builder()
                    .name("Sneha Desai")
                    .email("sneha.desai_work@yahoo.com")
                    .phone("8899001122")
                    .position("Housekeeping")
                    .resumeText("Looking for a housekeeping role. Worked previously at Grand Plaza for 2 yrs. Very punctual.")
                    .status("ACCEPTED")
                    .build();

            Application app3 = Application.builder()
                    .name("Arjun Nair")
                    .email("arjun.chef@hotmail.com")
                    .phone("7788990011")
                    .position("Chef")
                    .resumeText("Did my culinary course from IHM. Specialized in South Indian and Continental cuisine. Can handle high pressure kitchen environment.")
                    .status("REJECTED")
                    .build();

            applicationRepository.saveAll(List.of(app1, app2, app3));
            log.info("Applications seeded successfully.");
        } else {
            log.info("Applications already exist. Skipping seeding.");
        }
    }
}
