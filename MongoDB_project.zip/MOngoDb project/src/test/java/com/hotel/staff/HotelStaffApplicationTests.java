package com.hotel.staff;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelStaffApplicationTests {

    @Test
    void contextLoads() {
        // This test will simply verify that the Spring application context can start successfully
    }
}
