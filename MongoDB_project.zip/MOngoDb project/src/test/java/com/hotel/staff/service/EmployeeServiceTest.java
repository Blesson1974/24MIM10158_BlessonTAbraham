package com.hotel.staff.service;

import com.hotel.staff.dto.EmployeeRequest;
import com.hotel.staff.dto.EmployeeResponse;
import com.hotel.staff.mapper.EmployeeMapper;
import com.hotel.staff.model.Employee;
import com.hotel.staff.model.Role;
import com.hotel.staff.repository.EmployeeRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class EmployeeServiceTest {

    @Mock
    private EmployeeRepository employeeRepository;

    @Mock
    private EmployeeMapper employeeMapper;

    @Mock
    private PasswordEncoder passwordEncoder;

    @InjectMocks
    private EmployeeService employeeService;

    private Employee employee;
    private EmployeeRequest request;
    private EmployeeResponse response;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        
        employee = Employee.builder()
                .id("1")
                .name("John Doe")
                .email("john@test.com")
                .password("encoded_pass")
                .phone("1234567890")
                .salary(50000.0)
                .role(Role.STAFF)
                .build();

        request = EmployeeRequest.builder()
                .name("John Doe")
                .email("john@test.com")
                .password("raw_pass")
                .phone("1234567890")
                .salary(50000.0)
                .role(Role.STAFF)
                .build();

        response = EmployeeResponse.builder()
                .id("1")
                .name("John Doe")
                .email("john@test.com")
                .phone("1234567890")
                .salary(50000.0)
                .role(Role.STAFF)
                .build();
    }

    @Test
    void testGetAllEmployees() {
        Page<Employee> page = new PageImpl<>(List.of(employee));
        when(employeeRepository.findAll(any(PageRequest.class))).thenReturn(page);
        when(employeeMapper.toResponse(employee)).thenReturn(response);

        Page<EmployeeResponse> result = employeeService.getAllEmployees(PageRequest.of(0, 10));

        assertEquals(1, result.getTotalElements());
        assertEquals("John Doe", result.getContent().get(0).getName());
    }

    @Test
    void testGetEmployeeById_Success() {
        when(employeeRepository.findById("1")).thenReturn(Optional.of(employee));
        when(employeeMapper.toResponse(employee)).thenReturn(response);

        EmployeeResponse result = employeeService.getEmployeeById("1");

        assertNotNull(result);
        assertEquals("john@test.com", result.getEmail());
    }

    @Test
    void testCreateEmployee_Success() {
        when(employeeRepository.existsByEmail(anyString())).thenReturn(false);
        when(employeeMapper.toEntity(request)).thenReturn(employee);
        when(passwordEncoder.encode("raw_pass")).thenReturn("encoded_pass");
        when(employeeRepository.save(any(Employee.class))).thenReturn(employee);
        when(employeeMapper.toResponse(employee)).thenReturn(response);

        EmployeeResponse result = employeeService.createEmployee(request);

        assertNotNull(result);
        assertEquals("John Doe", result.getName());
        verify(employeeRepository, times(1)).save(any(Employee.class));
    }
}
