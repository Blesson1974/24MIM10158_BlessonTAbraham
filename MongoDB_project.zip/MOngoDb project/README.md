# Hotel Staff Management System

## Overview

The Hotel Staff Management System is a backend application developed using **Java 21**, **Spring Boot**, and **MongoDB** to simplify the management of hotel employees. It provides a centralized platform for staff applications, employee registration, secure login, and manager operations through REST APIs.

The project follows a layered architecture, making the code modular, maintainable, and scalable.

---

## Features

### Staff Application
- Submit job applications
- Store applicant details
- Track application status

### Staff Registration
- Register new employees
- Securely store employee information

### Staff Login
- JWT-based authentication
- BCrypt password encryption

### Manager Operations
- View employees
- Search employees
- Update employee information
- Delete employee records
- Update salaries
- Review applications

---

## Technology Stack

| Technology | Purpose |
|------------|---------|
| Java 21 | Programming Language |
| Spring Boot | Backend Framework |
| Spring Data MongoDB | Database Layer |
| MongoDB | NoSQL Database |
| Spring Security | Authentication & Authorization |
| JWT | Authentication |
| Maven | Build Tool |

---

## Project Structure

```text
src
├── config
├── controller
├── service
├── repository
├── model
├── dto
├── mapper
├── security
├── exception
└── resources
```

---

## REST APIs

*All endpoints under `/api/employees` and `/api/applications` (except POST /applications) require a Bearer token.*

### Authentication
- POST /api/auth/register (Registers an employee and returns DTO)
- POST /api/auth/login (Returns JWT Token)

### Applications
- POST /api/applications (Public)
- GET /api/applications?page=0&size=10 (Manager)
- PUT /api/applications/{id} (Manager)

### Employees
- GET /api/employees?page=0&size=10 (Manager/Staff)
- GET /api/employees/{id} (Manager/Staff)
- POST /api/employees (Manager)
- PUT /api/employees/{id} (Manager)
- DELETE /api/employees/{id} (Manager)

Note: Employee passwords are intentionally omitted from all API responses for security purposes.

---


## Security

- Spring Security
- JWT Authentication
- BCrypt Password Hashing
- Role-Based Access Control

---

## Running the Project


mvn clean install

mvn spring-boot:run
```

Default URL:

```
http://localhost:8080
```

---

## Future Enhancements

- Attendance Management
- Leave Management
- Payroll
- Docker Support
- React Frontend
- Cloud Deployment

---

## Conclusion

This project demonstrates the use of Java 21, Spring Boot, and MongoDB to build a secure and scalable Hotel Staff Management backend application.

---

## Author

Developed as an academic project for learning enterprise backend development.
