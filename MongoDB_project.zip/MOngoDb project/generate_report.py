import os
from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH

def add_heading(doc, text, level):
    heading = doc.add_heading(text, level=level)
    return heading

def add_image_with_caption(doc, image_path, caption):
    try:
        if os.path.exists(image_path):
            doc.add_picture(image_path, width=Inches(6.0))
            p = doc.add_paragraph(caption)
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.runs[0].italic = True
            doc.add_paragraph("") # Space
        else:
            print(f"Image not found: {image_path}")
    except Exception as e:
        print(f"Error adding image {image_path}: {e}")

def main():
    doc = Document()
    
    # Title
    title = doc.add_heading('Project Report: Hotel Staff Management System', 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    # Summary
    add_heading(doc, '1. Project Summary', 1)
    doc.add_paragraph(
        "The Hotel Staff Management System is a robust, production-ready backend application designed to streamline the administration of hotel employees and job applicants. "
        "It provides secure RESTful APIs to manage employee records, authenticate users using JSON Web Tokens (JWT), handle role-based access control (Manager vs. Staff), "
        "and efficiently process new job applications with pagination and validation support."
    )

    # Outcome
    add_heading(doc, '2. Project Outcome', 1)
    doc.add_paragraph(
        "The project successfully implements a secure, scalable architecture where sensitive data (such as passwords) is carefully protected using Data Transfer Objects (DTOs). "
        "The database interactions are optimized with Spring Data MongoDB, and the API endpoints are fully hardened against invalid requests using Jakarta Bean Validation. "
        "The outcome is a highly maintainable, modern Spring Boot backend ready for frontend integration."
    )

    # Tools Used
    add_heading(doc, '3. Tools & Technologies Used', 1)
    tools = doc.add_paragraph()
    tools.add_run("• Language: ").bold = True
    tools.add_run("Java 21\n")
    tools.add_run("• Framework: ").bold = True
    tools.add_run("Spring Boot 3.3.0\n")
    tools.add_run("• Database: ").bold = True
    tools.add_run("MongoDB (NoSQL)\n")
    tools.add_run("• Security: ").bold = True
    tools.add_run("Spring Security & JWT (JSON Web Tokens)\n")
    tools.add_run("• Mapping: ").bold = True
    tools.add_run("MapStruct (Entity-DTO mapping)\n")
    tools.add_run("• Build Tool: ").bold = True
    tools.add_run("Maven\n")
    tools.add_run("• API Testing: ").bold = True
    tools.add_run("Postman\n")
    tools.add_run("• Database GUI: ").bold = True
    tools.add_run("MongoDB Compass")

    doc.add_page_break()

    # Output Screenshots - Postman
    add_heading(doc, '4. Output Screenshots: API Testing (Postman)', 1)
    
    screenshots_dir = os.path.join(os.getcwd(), 'Screenshots')

    postman_flows = [
        ("Register Employee.png", "Registering a new Employee via POST /api/auth/register. Generates BCrypt hashed password."),
        ("Login.png", "Authenticating user via POST /api/auth/login to receive a JWT Token for secure access."),
        ("Create employee.png", "Creating an employee using the protected POST /api/employees endpoint."),
        ("get all employee.png", "Retrieving paginated employee records via GET /api/employees. Notice passwords are NOT exposed."),
        ("get employee by id.png", "Fetching a single employee's details using their unique ID via GET /api/employees/{id}."),
        ("update employee.png", "Updating an employee's data (e.g. salary or role) using PUT /api/employees/{id}."),
        ("Delete employee.png", "Successfully deleting an employee record using DELETE /api/employees/{id}."),
        ("Submit application.png", "Submitting a new job application via POST /api/applications."),
        ("Get all Aplications.png", "Fetching the list of all job applications via GET /api/applications."),
        ("Update Applications.png", "Updating the status of a job application (e.g. to ACCEPTED) via PUT /api/applications/{id}.")
    ]

    for img_file, caption in postman_flows:
        img_path = os.path.join(screenshots_dir, img_file)
        add_heading(doc, img_file.replace('.png', ''), 2)
        add_image_with_caption(doc, img_path, caption)

    # Output Screenshots - MongoDB
    add_heading(doc, '5. Output Screenshots: Database Verification (MongoDB)', 1)

    mongo_flows = [
        ("mongodb collections.png", "Overview of the MongoDB Collections created by Spring Data."),
        ("mongodb post new employee.png", "Verifying the newly inserted Employee document in the database."),
        ("mongodb get employee.png", "Fetching the Employee records directly via MQL queries."),
        ("mongodb post  new application.png", "Verifying the newly inserted Job Application document."),
        ("mongodb get applications.png", "Fetching Application records to verify statuses."),
        ("mongodb get applications pages.png", "Viewing the comprehensive data structure inside MongoDB Compass.")
    ]

    for img_file, caption in mongo_flows:
        img_path = os.path.join(screenshots_dir, img_file)
        add_heading(doc, img_file.replace('.png', ''), 2)
        add_image_with_caption(doc, img_path, caption)

    doc.add_page_break()

    # Conclusion
    add_heading(doc, '6. Conclusion', 1)
    doc.add_paragraph(
        "The development of the Hotel Staff Management System effectively demonstrates the integration of modern backend technologies. "
        "By leveraging Java 21 and Spring Boot, we established a highly performant and secure server. The implementation of JWT ensures that APIs remain stateless and secure, "
        "while the adoption of MongoDB provides the flexibility required for dynamic employee and application data models. "
        "Overall, the final product meets all critical production standards including global exception handling, pagination, data validation, and strict DTO isolation."
    )

    doc.save('report.docx')
    print("Report generated successfully at report.docx")

if __name__ == "__main__":
    main()
